import React from "react";

export default function App() {
  return (
    <div style={{ fontFamily: "sans-serif", padding: "20px", direction: "rtl", background: "#f7f9fb" }}>
      <h1 style={{ textAlign: "center", color: "#2563eb" }}>
        موقع توعوي: الخصوصية في شبكات التواصل الاجتماعي
      </h1>
      <p style={{ textAlign: "center", color: "#555" }}>
        ملخصات سياسات الخصوصية + نصائح حماية + توعية بالهندسة الاجتماعية
      </p>

      <section style={{ background: "#fff", padding: "20px", marginTop: "20px", borderRadius: "10px" }}>
        <h2>🔒 ملخصات الخصوصية</h2>
        <ul>
          <li><strong>Facebook:</strong> يجمع بياناتك الشخصية وسلوكك الإعلاني ويشاركها مع المعلنين.</li>
          <li><strong>Instagram:</strong> يحلل صورك وموقعك وسلوكك لتخصيص المحتوى والإعلانات.</li>
          <li><strong>TikTok:</strong> يتتبع نشاطك بشكل دقيق لتحسين الاقتراحات الإعلانية.</li>
          <li><strong>X (Twitter):</strong> يستخدم تفاعلاتك لمتابعة اهتماماتك واستهدافك بالإعلانات.</li>
        </ul>
      </section>

      <section style={{ background: "#fff", padding: "20px", marginTop: "20px", borderRadius: "10px" }}>
        <h2>🧠 نصائح لحماية الخصوصية</h2>
        <ul>
          <li>استخدم كلمات مرور قوية وفريدة لكل حساب.</li>
          <li>فعّل التحقق الثنائي (2FA) لحساباتك.</li>
          <li>لا تضغط على الروابط المشبوهة أو غير المتوقعة.</li>
          <li>راجع إعدادات الخصوصية بشكل دوري.</li>
        </ul>
      </section>

      <section style={{ background: "#fff", padding: "20px", marginTop: "20px", borderRadius: "10px" }}>
        <h2>🎭 الهندسة الاجتماعية</h2>
        <p>
          الهندسة الاجتماعية هي أسلوب يستخدمه المهاجمون لخداع المستخدمين وسرقة معلوماتهم. 
          كن حذرًا من الرسائل التي تطلب بياناتك الشخصية أو كلمات المرور.
        </p>
      </section>

      <section style={{ background: "#fff", padding: "20px", marginTop: "20px", borderRadius: "10px" }}>
        <h2>📋 اختبار وعي سريع</h2>
        <p>إذا وصلك رابط من صديق بشكل غير متوقع، ماذا تفعل؟</p>
        <ol>
          <li>تضغط الرابط فورًا.</li>
          <li>تتواصل مع الصديق لتتأكد. ✅</li>
          <li>تعيد إرسال الرابط للآخرين.</li>
        </ol>
      </section>

      <footer style={{ textAlign: "center", marginTop: "30px", color: "#888" }}>
        موقع تجريبي لتوعية المستخدمين — مشروع تخرج
      </footer>
    </div>
  );
}
